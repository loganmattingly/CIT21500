var prompter = prompt("What is your name?");
var notCool = document.body.querySelector(".imNotCool");
notCool.innerHTML="My name is "+prompter;